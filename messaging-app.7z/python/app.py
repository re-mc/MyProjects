"""
Rust / Python App Template
Author: AitherNight
"""

import rust
import os, sys
from time import sleep

# Import flexx (library used for the gui), if it isn't installed, install it
try:
    from flexx import flx, ui
except ModuleNotFoundError:
    print('Flexx not found, installing...')
    if sys.platform not in ['linux', 'macos', 'other']:
        print('Windows detected.')
        os.system(f'python -m pip install flexx')
    else:
        print('Linux detected.')
        os.system(f'python3 -m pip install flexx')
    print('Flexx installed, please run the program again.')
    sleep(0.5)
    exit(0)


flx.assets.associate_asset(__name__, 'https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css')
flx.assets.associate_asset(__name__, 'https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js')


class PythonApp(flx.PyWidget):

    def init(self):
        self.messages = list()
        self.message_boxes = list()
        self.rust_version = flx.Label(text=f'Application Version: {str(rust.get_pkg_ver())}')
        self.vbox = flx.VBox()
        self.formlayout = flx.Layout(style='overflow-y: scroll;')
        with self.formlayout:
            self.chat_box = flx.LineEdit(placeholder_text='message')
            self.chat_log_box = flx.Label(text='')

    def render_messages(self):
        print('Rendering')
        for i in self.message_boxes:
            i.dispose()
            # popped = self.message_boxes[-1]
            # self.message_boxes.pop(-1)
            print(f'Disposed {i}, Popped {None}')
        with self.formlayout:
            for i in self.messages:
                self.message_boxes.append(flx.Label(text=i, flex=1))
                print(f'Created {i}')

    @flx.reaction('chat_box.submit')
    def submit_message(self, *events):
        rust.send_message(self.chat_box.text)
        self.messages.insert(0, f'(You) | {self.chat_box.text}')
        self.chat_box.set_text('')
        self.render_messages()


def main():
    app = flx.App(PythonApp, title='Rust-Python App', icon='https://rust-lang.org/logos/rust-logo-512x512.png')
    app.launch('app')

    flx.run()
